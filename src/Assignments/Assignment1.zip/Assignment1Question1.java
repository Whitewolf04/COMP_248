//----------------------------------------------
// Assignment 1 - Question 1
// Written by: Minh Tuan To - 40114920
// For COMP 248 Section EC  - Fall 2019
//----------------------------------------------

public class Assignment1Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Output
		System.out.println("Welcome to COMP 248 Java Programming!\n"
				+ "Let's use programming to have some coffee when you work!\n"
				+ "while (Working)\n"
				+ "{\n"
				+ "\tCoffeeMug.Drink();\n"
				+ "\tworkTask.Execute();\n"
				+ "\tif (coffeeMug == \"Empty\")\n"
				+ "\t{\n"
				+ "\t\tif (coffeePot == \"Empty\")\n"
				+ "\t\t\tcoffeePot.Make();\n"
				+ "\t\tcoffeeMug.Refill();\n"
				+ "\t}\n"
				+ "\tEnjoy your coffee!\n"
				+ "}"
				);
		//End of program

	}

}
